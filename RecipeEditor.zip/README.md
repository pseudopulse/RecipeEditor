# RecipeEditor

WRB's Halcyon Shrine rework as a standalone mod.

Moves the Halcyon Shrine to be a guaranteed spawn on stage 3 (specifically stages that can spawn the Access Node, in vanilla this is s3)
Halcyon Shrine takes up no credits and cannot spawn naturally in any other way, only appear in its guaranteed spawn

Halcyon Shrine is changed to no longer be a holdout zone, and instead costs $150 immediately to activate (also disabled after TP starts or once an access node has been used)
Using the Halcyon Shrine adds a green orb to the teleporter, and adds 1 Mountain Shrine stack worth of difficulty (no extra rewards from this)

During the teleporter event after using the shrine, a lightning storm carpets the area outside of the teleporter radius, inflicting 5s of Lunar Ruin to players hit by it. Lightning will never target areas inside of the TP bubble.
Halcyonites will spawn naturally during the storm, as a seperate enemy flow that doesnt take up spawn credits from the main TP (these halcyonites arent gilded and dont get the shrine buff that vanilla halcyonite does)

Clearing the TP drops an Aurelionite Fragment for all players (5 choices, pick 3, does not have the "guaranteed 2 sots items" restriction that vanilla has)


ColossusMainStages is not a hard dependency and you may remove it, however the colossus path stages will become inaccessible without some mod to add another means to access them (a green portal on stage 3 takes you directly to Prime Meridian)